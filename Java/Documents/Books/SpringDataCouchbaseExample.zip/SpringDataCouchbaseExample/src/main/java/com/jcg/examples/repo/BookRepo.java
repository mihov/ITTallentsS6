package com.jcg.examples.repo;

import org.springframework.data.couchbase.repository.CouchbaseRepository;
import org.springframework.stereotype.Repository;

import com.jcg.examples.entity.Book;

@Repository
public interface BookRepo extends CouchbaseRepository<Book, Long>
{
		
	/*	@Query(value="select * from JavaCodeGeeks")
		public List<Book> getBooksByContainedWord(String containedString);*/
		
		
}
