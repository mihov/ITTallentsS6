package com.danibuiza.javacodegeeks.reflection;

public class InformationClass implements InformationInterface
{

    public String getInfo(){
        return "information";
    }
    
}
