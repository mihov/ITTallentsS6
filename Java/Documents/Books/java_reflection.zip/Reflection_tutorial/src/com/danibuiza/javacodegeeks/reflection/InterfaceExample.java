package com.danibuiza.javacodegeeks.reflection;

public interface InterfaceExample
{

}
