package suppliers;

public class SmallSupplier extends Supplier{
	
	@Override
	public int getDiscount() {
		return 0;
	}
}
