package suppliers;

public abstract class Supplier {

	private String address;
	private String workingTime;
	private String name;
	
	public abstract int getDiscount();
}
