package tradingObj;

public interface IETShop {

}
