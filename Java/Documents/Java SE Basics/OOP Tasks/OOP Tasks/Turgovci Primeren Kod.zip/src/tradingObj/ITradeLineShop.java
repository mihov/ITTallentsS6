package tradingObj;

public interface ITradeLineShop {

}
