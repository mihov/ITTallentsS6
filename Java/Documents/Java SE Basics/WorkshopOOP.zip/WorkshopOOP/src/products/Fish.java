package products;

public class Fish extends ProductByKg{

	public Fish(String name, double price, double quantity) throws InvalidProductException {
		super(name, price, quantity);
	}

}
