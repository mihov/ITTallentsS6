import java.util.Scanner;

public class Task04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("�������� �: ");
		int a = sc.nextInt();

		System.out.print("�������� B: ");
		int b = sc.nextInt();
		
		if (a > b) {
			System.out.println(b + " " + a);
		} else {
			System.out.println(b + " " + a);
		}

	}

}
