
public class Task04 {

	public static void main(String[] args) {

		for (int i = 10; i >0; i--) {
			System.out.print(i + " ");
		}
	}

}
